package garage;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class GarageTests {
    private Garage garage;
    private Car audi;
    private Car bmw;
    private Car mercedes;

    @Before
    public void setUp(){
        this.garage=new Garage();
        audi=new Car("Audi", 300, 29000);
        bmw=new Car("BMW", 280, 35000);
        mercedes=new Car("Mercedes", 350, 40000);
    }

    @Test
    public void testAddCar(){
        garage.addCar(audi);
        Assert.assertEquals(1, garage.getCount());
        garage.addCar(bmw);
        Assert.assertEquals(2, garage.getCount());
        garage.addCar(mercedes);
        Assert.assertEquals(3, garage.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddCarShouldFailIfAddNull(){
        Garage garage=new Garage();
        garage.addCar(null);
    }

    @Test
    public void testGetTheMostExpensiveCar(){
        Garage garage=new Garage();
        Car Audi=new Car("Audi", 200, 30000);
        Car BMW=new Car("BMW", 220, 35000);
        garage.addCar(Audi);
        garage.addCar(BMW);
        Car mostExpensiveCar=garage.getTheMostExpensiveCar();
    }

    @Test
    public void testFindAllCarsByBrand(){
        garage.addCar(audi);
        garage.addCar(bmw);
        garage.addCar(mercedes);
        garage.findAllCarsByBrand(audi.getBrand());
    }

    @Test
    public void testGetCarsSuccessfully(){
        garage.addCar(mercedes);
        List<Car> carInGarage=garage.getCars();
        Assert.assertEquals(1, garage.getCount());
        Assert.assertEquals(mercedes.getBrand(), carInGarage.get(0).getBrand());

    }

    @Test
    public void testFindAllCarsWithMaxSpeedAbove() {
        Garage garage=new Garage();
        Car Audi=new Car("Audi", 200, 30000);
        Car BMW=new Car("BMW", 220, 35000);
        Car AudiA4=new Car("Audi", 250, 42000);
        garage.addCar(Audi);
        garage.addCar(BMW);
        garage.addCar(AudiA4);
        garage.findAllCarsWithMaxSpeedAbove(250);

    }
}