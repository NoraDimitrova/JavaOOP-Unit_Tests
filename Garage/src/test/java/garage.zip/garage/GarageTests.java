package garage;

import org.junit.Assert;
import org.junit.Test;

import java.util.List;

public class GarageTests {
    @Test
    public void testAddCar(){
        Garage garage=new Garage();
        Car Audi=new Car("Audi", 200, 30000);
        Car BMW=new Car("BMW", 220, 35000);
        garage.addCar(Audi);
        garage.addCar(BMW);
        Assert.assertEquals(2, garage.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddCarShouldFailIfAddNull(){
        Garage garage=new Garage();
        garage.addCar(null);
    }

    @Test
    public void testGetTheMostExpensiveCar(){
        Garage garage=new Garage();
        Car Audi=new Car("Audi", 200, 30000);
        Car BMW=new Car("BMW", 220, 35000);
        garage.addCar(Audi);
        garage.addCar(BMW);
        Car mostExpensiveCar=garage.getTheMostExpensiveCar();
    }

    @Test
    public void testFindAllCarsByBrand(){
        Garage garage=new Garage();
        Car Audi=new Car("Audi", 200, 30000);
        Car BMW=new Car("BMW", 220, 35000);
        Car AudiA4=new Car("Audi", 250, 42000);
        garage.addCar(Audi);
        garage.addCar(BMW);
        garage.addCar(AudiA4);
        garage.findAllCarsByBrand(Audi.getBrand());
    }

    @Test
    public void testFindAllCarsWithMaxSpeedAbove() {
        Garage garage=new Garage();
        Car Audi=new Car("Audi", 200, 30000);
        Car BMW=new Car("BMW", 220, 35000);
        Car AudiA4=new Car("Audi", 250, 42000);
        garage.addCar(Audi);
        garage.addCar(BMW);
        garage.addCar(AudiA4);
        garage.findAllCarsWithMaxSpeedAbove(250);

    }
}